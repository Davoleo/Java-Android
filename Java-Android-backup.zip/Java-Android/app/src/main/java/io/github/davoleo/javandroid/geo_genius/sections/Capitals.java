package io.github.davoleo.javandroid.geo_genius.sections;

import android.app.Activity;
import android.os.Bundle;
import net.davoleo.java_android.R;

public class Capitals extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capitals);
    }

}
